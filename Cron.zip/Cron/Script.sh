#!/bin/bash

#Busvar Videos Pendientes de Conversion
BD=sqlite3 /home/ubuntu/workspace/db/development.sqlite3
LIST=`$BD "select id,video_original_file_name,email from competitors where status_video = 'En Proceso';"`

#Iterar Videos
for ROW in $LIST; do

    #Obtener Identificador del video
    id=`echo $ROW | awk '{split($0,a,"|"); print a[1]}'`
    #Obtener Nombre del Video
    nombre=`echo $ROW | awk '{split($0,a,"|"); print a[2]}'`
    #Obtener Correo Electronico Competidor
    correo=`echo $ROW | awk '{split($0,a,"|"); print a[3]}'`
    
    #PATH VIDEO
    PATH_VIDEOS=public/system/competitors/video_original/000/000/$id/original/
    
    #Convertir Videos
    ffmpeg -i $PATH_VIDEOS/$nombre -codec:v libx264 -codec:a libfdk_aac $nombre.mp4
    
    #Actualizar Estado Video
    $BD "update competitors set status_video = 'Convertido', video_converted_file_name = $nombre.mp4 where id = $id;"
    
    #Enviar Correo
    sendEmail -f admin@UniCloud.com -t $Correo -s smtp.gmail.com -u 'Video Convertido' -m the 'Su video ha sido convertido y puede ser visualizado.'
    
done