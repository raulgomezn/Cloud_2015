#Crontab que ejecuta el script de conversión cada 10 minutos
10 * * * * <Usuarios_Sistema_Operativo> /home/<Usuarios_Sistema_Operativo>/scripts/script.sh